define([
    'angular'

], function (angular) {
    'use strict';

    var controllers =  angular.module('app.orgControllers',[])
        .controller('organizationController', ['$rootScope','$scope', organizationController])
        
    function organizationController($rootScope,$scope) {
    	
    	var vm = this;
        vm.pageName = "Home/Organizations";
     	var vis = require("vis");
        console.log("VIS ::",vis);
        
        // create an array with nodes
        var nodes = new vis.DataSet([
            {id: 1, label: 'Verifications'},
            {id: 2, label: 'Medicaid'},
            {id: 3, label: 'Income'},
            {id: 4, label: 'X1 Rulesheet'},
            {id: 5, label: 'X2 Rulesheet'}
        ]);
        console.log('nodes ::',nodes);
        
        // create an array with edges
        var edges = new vis.DataSet([
            {from: 1, to: 3},
            {from: 1, to: 2},
            {from: 2, to: 4},
            {from: 2, to: 5}
        ]);
        console.log('edges ::',edges);
        
        var container = document.getElementById('mynetwork'); //$('#mynetwork'); //change this to ngDirective
        console.log('container ::',container);
        // provide the data in the vis format
        var data = {
            nodes: nodes,
            edges: edges
        };
        var options = {
          /*configure: {
            enabled: false,
              container: undefined,//container, //mynetwork1,
              showButton: true
          },*/ 
        nodes:{
            shape: 'box',
            shapeProperties: {
              borderDashes: false, // only for borders
              borderRadius: 6,     // only for box shape
              interpolation: false,  // only for image and circularImage shapes
              useImageSize: false,  // only for image and circularImage shapes
              useBorderWithImage: false  // only for image shape
            },
            size: 25
        },      
        manipulation: {
            enabled: true,
            initiallyActive: true,
            addNode: true,
            addEdge: true,
            editEdge: true,
            deleteNode: true,
            deleteEdge: true,
            controlNodeStyle:{
              // all node options are valid.
            }
          },    
          edges:{
            arrows: {
              to:     {enabled: true, scaleFactor:1, type:'arrow'},
              middle: {enabled: false, scaleFactor:1, type:'arrow'},
              from:   {enabled: false, scaleFactor:1, type:'arrow'}
            },
            arrowStrikethrough: true,
            chosen: true,
            color: {
              color:'#f40808',
              highlight:'#848484',
              hover: '#848484',
              inherit: 'from',
              opacity:1.0
            }
          },
          physics: true  
        }
        
        var network = new vis.Network(container, data, options);

        console.log('organizationController loaded');
        
        
        
    } //End of organizationController

    return controllers;

});
